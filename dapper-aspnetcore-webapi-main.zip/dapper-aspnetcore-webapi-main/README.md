# Using Dapper with ASP.NET Core Web API
## https://code-maze.com/using-dapper-with-asp-net-core-web-api
This repo contains the source code for the "Using Dapper with ASP.NET Core Web API" article on Code Maze
